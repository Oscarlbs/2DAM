import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		int seleccion;

		do {

			seleccion = JOptionPane.showOptionDialog(

					null, "MENU DE OPCIONES", null, JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
					null, new Object[] { "1. Crear Archivo", "2. Mostrar Archivo", "3. Terminar" }, null);

			switch (seleccion) {

			case 0:
				crearFichero();
				break;
			case 1:
				mostrarFichero();
				break;
			case 2:
				System.out.println("\nFIN DE PROGRAMA");
				break;
			default:
				System.out.println("\nOpci�n inv�lida.");
				break;

			}

		} while (seleccion == 0);

	}

	public static void crearFichero() {
		FileWriter fw = null;
		try {
			fw = new FileWriter("C:\\Users\\oscar\\Desktop\\usuario.txt");
			System.out.println("�FICHERO CREADO CON EXITO!");
			PrintWriter pw = new PrintWriter(fw);
			escribirFichero(pw);
			pw.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (fw != null) {
					fw.close();
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

	}

	public static void escribirFichero(PrintWriter pw) throws Exception {

		try (Scanner teclado = new Scanner(System.in)) {
			String opcion;
			System.out.println("INTRODUZCA LOS DATOS POR ORDEN: ");
			System.out.println("Nombre: ");
			opcion = teclado.nextLine();
			pw.println(opcion);
			System.out.println("Apellidos: ");
			opcion = teclado.nextLine();
			pw.println(opcion);
			System.out.println("FECHA DE NACIMIENTO: ");
			opcion = teclado.nextLine();
			pw.println(opcion);
		}

		System.out.println("�Datos almacenados con exito!");

	}

	public static void mostrarFichero() {
		FileReader fr = null;
		try {
			File fichero = new File("C:\\Users\\oscar\\Desktop\\usuario.txt");
			fr = new FileReader(fichero);
			BufferedReader br = new BufferedReader(fr);
			leerFichero(br);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (fr != null) {
					fr.close();
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public static void leerFichero(BufferedReader br) throws Exception {
		String linea;
		linea = br.readLine();
		while (linea != null) {

			System.out.println(linea);
			linea = br.readLine();
		}
	}
}
