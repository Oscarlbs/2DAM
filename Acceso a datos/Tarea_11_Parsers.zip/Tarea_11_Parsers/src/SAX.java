import javax.swing.JTextArea;

public class SAX {
	
	public void crearEvento() {
		
	}
	
	public JTextArea mostrarEvento(JTextArea cuadro) {
		String contenido = "prueba";
		cuadro.setText(contenido);
		return cuadro;
	}
	
	public void añadirEvento() {
		
	}
}
