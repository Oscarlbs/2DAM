import javax.swing.JTextArea;

public class StAX {

	public void crear() {
		
	}
	
	public void mostrar() {
		
	}
	
	public void APICursor() {
		
	}
	
	public void APIEvents() {
		
	}
}
