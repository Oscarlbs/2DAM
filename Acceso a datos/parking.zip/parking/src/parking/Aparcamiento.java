package parking;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Aparcamiento {
	static String id;
	static String marca;
	static String listado;
	static String color;
	static String matricula;
	static String fecha;
	

	public static void main(String[] args) throws IOException {
		int opcion;
		Scanner sc = new Scanner(System.in);
		do {
			
			System.out.println("BIENVENIDO AL PARKING MUNICIPAL DE VIGO:");
			System.out.println("1. Crear FICHERO");
			System.out.println("2. INTRODUCIR LOS DATOS DE TU VEHICULO");
			System.out.println("3. Mostrar entradas");
			System.out.println("4. Mostrar salidas");
			System.out.println("5. Alta de un vehiculo nuevo");
			System.out.println("6. Entrada de un vehiculo");
			System.out.println("7. Salida de un vehiculo");
			System.out.println("8. Salir");
			System.out.print("Seleccione una opcion: ");
			opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				crearFicheros();
				break;
			case 2:
				crearVehiculo();
				break;
			case 3:
				entradaVehiculo();
				break;
			case 4:
				mostrarSalidas();
				break;
			case 7:
				salidaVehiculo();
				break;
			case 8:
				System.out.println("Saliendo del programa...");
				break;
			default:
				System.out.println("Opcion no valida, por favor seleccione una opcion valida.");
				break;
			}
		} while (opcion != 8);
	}
	
	private static void crearFicheros() {

		File listado = new File("Listado.txt");
		try {
			listado.createNewFile();
			System.out.println("Archivo Listado.txt creado con Exito.");
		} catch (IOException e) {
			System.out.println("Error al crear archivo Listado.txt");
			e.printStackTrace();
		}
	}
	
	private static void entradaVehiculo() {
		
		File entradas = new File("Entradas.txt");try
		{
			entradas.createNewFile();
			System.out.println("Archivo Entradas.txt creado con éxito.");
		}catch(
		IOException e)
		{
			System.out.println("Error al crear archivo Entradas.txt");
			e.printStackTrace();
		}
		
	}

	private static void salidaVehiculo() {
		
		
		File salidas = new File("Salidas.txt");
		try
		{
			salidas.createNewFile();
			System.out.println("Archivo Salidas.txt creado con éxito.");
		}catch(
		IOException e)
		{
			System.out.println("Error al crear archivo Salidas.txt");
			e.printStackTrace();
		}

		
	}

	

	private static void crearVehiculo() {
		
		Scanner sc = new Scanner(System.in);System.out.print("Ingrese el identificador del coche: ");
		String id = sc.nextLine();System.out.print("Ingrese la marca del coche: ");
		String marca = sc.nextLine();System.out.print("Ingrese el color del coche: ");
		String color = sc.nextLine();System.out.print("Ingrese la matrícula del coche: ");
		String matricula = sc.nextLine();System.out.print("Ingrese la fecha del último movimiento del coche (dd/mm/yyyy): ");
		String fecha = sc.nextLine();
		
	}

	private static void mostrarSalidas() throws IOException {
		
	
		FileWriter writer = null;
		
		writer.write("IDENTIFICADOR: " + id + "\n");
		writer.write("MARCA: " + marca + "\n");
		writer.write("COLOR: " + color + "\n");
		writer.write("MATRÍCULA: " + matricula + "\n");
		writer.write("ÚLTIMO MOVIMIENTO: " + fecha + "\n");
		writer.close();
		try {
			writer = new FileWriter(listado, true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Información del coche registrada en el archivo Listado.txt con éxito.");

	
	
	
	}
}
