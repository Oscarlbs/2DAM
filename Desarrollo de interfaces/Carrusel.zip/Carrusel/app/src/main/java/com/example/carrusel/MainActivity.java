package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ViewFlipper;
import org.imaginativeworld.whynotimagecarousel.CarouselItem;
import org.imaginativeworld.whynotimagecarousel.ImageCarousel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<CarouselItem> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageCarousel carousel = findViewById(R.id.carousel);
        list.add(new CarouselItem("https://www.km77.com/images/medium/8/3/4/9/ferrari-california-t-exterior.308349.jpg", "Ferrari California"));
        list.add(new CarouselItem("https://cdn.motor1.com/images/mgl/RPrgg/s3/bmw-m4-competition-kith-design-study-edition-lead-image.jpg", "Bmw M4 Competition"));
        list.add(new CarouselItem("https://motor.elpais.com/wp-content/uploads/2022/03/Mercedes-AMG-GT-Black-Series-Safety-Car-F1.jpg", "Mercedes Amg Gt Special Edition"));

        carousel.addData(list);

    }
}