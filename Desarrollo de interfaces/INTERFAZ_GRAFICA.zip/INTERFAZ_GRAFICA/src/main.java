import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class main extends JFrame {
  private JTextArea textArea;
  private JLabel statusLabel;
  private JButton clearButton;

  public main() {
    setTitle("XML Parsers Application");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);
    add(scrollPane, BorderLayout.CENTER);

    statusLabel = new JLabel("Ready");
    add(statusLabel, BorderLayout.SOUTH);

    clearButton = new JButton("Clear");
    clearButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        textArea.setText("");
      }
    });
    add(clearButton, BorderLayout.NORTH);

    JMenuBar menuBar = new JMenuBar();
    JMenu manageMenu = new JMenu("Gestionar");
    JMenuItem manageDOMMenu = new JMenuItem("DOM");
    JMenuItem manageSAXMenu = new JMenuItem("SAX");
    JMenuItem manageStAXMenu = new JMenuItem("StAX");
  
    manageMenu.add(manageDOMMenu);
    manageMenu.add(manageSAXMenu);
    manageMenu.add(manageStAXMenu);
    menuBar.add(manageMenu);

    JMenu validationMenu = new JMenu("Validación");
    JMenuItem XSDMenu = new JMenuItem("XSD");
    JMenuItem DTDMenu = new JMenuItem("DTD");
    validationMenu.add(XSDMenu);
    validationMenu.add(DTDMenu);
    menuBar.add(validationMenu);

    JMenuItem JAXBMenu = new JMenuItem("JAXB");
    menuBar.add(JAXBMenu);

    setJMenuBar(menuBar);

    pack();
    setLocationRelativeTo(null);
  }

  public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run() {
        new main().setVisible(true);
      }
    });
  }
}
