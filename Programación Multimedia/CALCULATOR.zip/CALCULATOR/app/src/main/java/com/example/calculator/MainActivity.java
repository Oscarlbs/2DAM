package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnUno, btnDos, bntTres, btnCuatro, btnCinco, bntSeis, btnSiete, btnOcho, bntNueve, btnSuma,
            btnResta, btnMultiplica, btnDivide, btnClean, btnBorrar, btnPunto, btnIgual;
    TextView Resultado;
    double resultado;
    String operador, mostrar, reserva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUno = (Button) findViewById(R.id.Uno);
        btnDos = (Button) findViewById(R.id.dos);
        bntTres = (Button) findViewById(R.id.tres);
        btnCuatro = (Button) findViewById(R.id.cuatro);
        btnCinco = (Button) findViewById(R.id.cinco);
        bntSeis = (Button) findViewById(R.id.seis);
        btnSiete = (Button) findViewById(R.id.siete);
        btnOcho = (Button) findViewById(R.id.ocho);
        bntNueve = (Button) findViewById(R.id.nueve);
        btnSuma = (Button) findViewById(R.id.sumar);
        btnResta = (Button) findViewById(R.id.restar);
        btnMultiplica = (Button) findViewById(R.id.multiply);
        btnDivide = (Button) findViewById(R.id.Divide);
        btnClean = (Button) findViewById(R.id.Clean);
        btnBorrar = (Button) findViewById(R.id.Borrar);
        Resultado = (TextView) findViewById(R.id.Etiqueta);
        btnPunto = (Button) findViewById(R.id.punto);
        btnIgual = (Button) findViewById(R.id.igual);


        btnUno.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "1";
                Resultado.setText(mostrar);
            }

        });
        btnDos.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "2";
                Resultado.setText(mostrar);
            }

        });
        bntTres.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "3";
                Resultado.setText(mostrar);
            }

        });
        btnCuatro.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "4";
                Resultado.setText(mostrar);
            }

        });
        btnCinco.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "5";
                Resultado.setText(mostrar);
            }

        });
        bntSeis.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "6";
                Resultado.setText(mostrar);
            }

        });
        btnSiete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "7";
                Resultado.setText(mostrar);
            }

        });
        btnOcho.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "8";
                Resultado.setText(mostrar);
            }

        });
        bntNueve.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "9";
                Resultado.setText(mostrar);
            }

        });
        btnSuma.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                operador = "+";
                Resultado.setText("");
            }

        });
        btnResta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                operador = "-";
                Resultado.setText("");
            }

        });
        btnMultiplica.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                operador = "*";
                Resultado.setText("");
            }

        });
        btnDivide.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                operador = "/";
                Resultado.setText("");
            }

        });
        btnPunto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                operador = ".";
                Resultado.setText(mostrar);
            }

        });
        btnClean.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mostrar = "";
                Resultado.setText(mostrar);
                reserva = "";
                operador = "";
            }

        });
        btnBorrar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar.substring(0, mostrar.length() - 1);
                Resultado.setText(mostrar);
            }

        });
        btnIgual.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                mostrar = Resultado.getText().toString();
                mostrar = mostrar + "1";
                if (operador.equals("-")) {
                    resultado = Double.parseDouble(reserva) -
                            Double.parseDouble(Resultado.getText().toString());
                    Resultado.setText(String.valueOf(resultado));

                }

                if (operador.equals("+")) {
                    resultado = Double.parseDouble(reserva) +
                            Double.parseDouble(Resultado.getText().toString());
                    Resultado.setText(String.valueOf(resultado));

                }

                if (operador.equals("/")) {
                    resultado = Double.parseDouble(reserva) +
                            Double.parseDouble(Resultado.getText().toString());
                    Resultado.setText(String.valueOf(resultado));
                }
                if (operador.equals("*")) {
                    resultado = Double.parseDouble(reserva) +
                            Double.parseDouble(Resultado.getText().toString());
                    Resultado.setText(String.valueOf(resultado));

                }
            }

        });

    }
}













