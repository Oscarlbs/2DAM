package com.example.miscontactos;

public class Contacts {

    private int id,user;

    private String nombre, apellidos, telefono, email, direccion, apodo;



    //GETTERS AND SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getApodo() {
        return apodo;
    }

    public void setApodo(String apodo) {
        this.apodo = apodo;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    //CONSTRUCTOR
    public Contacts(int id, String nombre, String apellidos, String telefono, String email, String direccion, String apodo, int user){
        this.id=id;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.telefono=telefono;
        this.email=email;
        this.direccion=direccion;
        this.apodo= apodo;
        this.user=user;
    }


    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Contacto {" + "Nombre='" + nombre + '\'' + ", Apellidos='" + apellidos + '\'' + ", Teléfono='" + telefono + '\'' + ", Correo='" + email + '\'' + ", Dirección='" + direccion + '\'' + ", apodo='" + apodo + '\'' +'}';

    }
}
