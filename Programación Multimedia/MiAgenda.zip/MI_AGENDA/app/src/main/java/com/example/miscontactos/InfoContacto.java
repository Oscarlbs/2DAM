package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class InfoContacto extends AppCompatActivity {

    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_contacto);

        if (getSupportActionBar() != null) getSupportActionBar().hide();
        listView=findViewById(R.id.listView2);
        Bundle b=getIntent().getExtras();
        int id=b.getInt("clave");
        String nombre=b.getString("Nombre","default");
        String apellidos= b.getString("Apellidos","default");
        String telefono=b.getString("Teléfono","default");
        String Correo=b.getString("Correo","default");
        String direccion=b.getString("Dirección","default");
        String apodo=b.getString("apodo","default");



        //ICONOS ORDENADOS
        int imagenes[]={R.drawable.icono,R.drawable.telefono,
                R.drawable.correo, R.drawable.direccion, R.drawable.apodo};

        //INFORMACION DEL USUARIO
        String datos[]={nombre+ " "+apellidos, telefono, Correo, direccion, apodo};


        InfoContacto.MyAdapter adapter=new InfoContacto.MyAdapter(this, datos, imagenes);
        listView.setAdapter(adapter);

        ImageView iv=findViewById(R.id.perfil);

        TextView tv= findViewById(R.id.nombreinfo);
        tv.setText(nombre);

    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        String nombres[];
        int user[];

        MyAdapter(Context c, String nombres[],int user[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.user=user;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row2, parent, false);

            ImageView im=row.findViewById(R.id.image2);
            TextView nombre=row.findViewById(R.id.nombre2);

            im.setImageResource(user[position]);
            nombre.setText(nombres[position]);

            return row;
        }
    }
}