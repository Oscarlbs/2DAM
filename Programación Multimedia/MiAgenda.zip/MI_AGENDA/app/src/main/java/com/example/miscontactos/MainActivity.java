package com.example.miscontactos;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ArrayList<Contacts>contactos=new ArrayList<Contacts>();

    ListView listView;

    private static final int[]USER={R.drawable.icono, R.drawable.icono2, R.drawable.icono, R.drawable.icono,
            R.drawable.icono, R.drawable.icono, R.drawable.icono,R.drawable.icono, R.drawable.icono};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactos=iniciarContactos();

        listView=findViewById(R.id.listView2);

        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getUser(contactos));
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(MainActivity.this, InfoContacto.class);

                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("clave",contactos.get(position).getId());
                intent.putExtra("Nombre", contactos.get(position).getNombre());
                intent.putExtra("Apellidos", contactos.get(position).getApellidos());
                intent.putExtra("apodo", contactos.get(position).getApodo());
                intent.putExtra("Teléfono", contactos.get(position).getTelefono());
                intent.putExtra("Correo", contactos.get(position).getEmail());
                intent.putExtra("Dirección", contactos.get(position).getDireccion());
                startActivity(intent);
                finish();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }


    class MyAdapter extends ArrayAdapter<String>{
        Context context;
        String nombres[];
        String apodos[];
        int USER[];

        MyAdapter(Context c, String nombres[], String apodos[],int USER[]){
            super(c, R.layout.row, R.id.nombre,nombres);
            this.context=c;
            this.nombres=nombres;
            this.apodos=apodos;
            this.USER=USER;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater=(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row=layoutInflater.inflate(R.layout.row, parent, false);
            TextView nombre=row.findViewById(R.id.nombre);
            TextView apodo=row.findViewById(R.id.apodo);
            nombre.setText(nombres[position]);
            apodo.setText(apodos[position]);
            return row;
        }
    }

    private ArrayList<Contacts> iniciarContactos(){
        ArrayList<Contacts>contactos=new ArrayList<Contacts>();


        SharedPreferences sh=getSharedPreferences("MyPrefs", MODE_PRIVATE);

        //CONTACTOS RECOGIDOS
        int totales=sh.getInt("totales",8);

        String[]apodosDef={"Spaguetti","El pipas","boniato","el amargado","jefa","la yessi","el serger"," driver"};
        String[]nombsDef={"Oscar","Pedro","David","Xandre","Naila","Yessica","Sergio","Javier"};
        String[]apesDef={"Lopez-Boado", "Armada Rodriguez", "Fernandez", "Martínez Correia", "Álvarez Suárez", "Rodríguez González","Fernández Rodríguez","Loureiro Pérez"};
        String[]emailsDef={"oscar@gmail.com", "pedro@gmail.com", "david@gmail.com","xandre@gmail.com","naila@gmail.com","yessica@gmail.com","sergio@gmail.com","javier@gmail.com"};
        String[]direccionesDef={"Vigo","calle el motín","gran vía","Marcela diaz","teis","ponteareas","Garcia Barbon","Mirador de montepinar"};
        int[]userDef={5,2,4,8,6,3,1,7,0};

        String nombre, apellidos, telefono, email,direccion,apodo;
        int id, user;
        for(int i=0;i<totales;i++){
            if(sh.getBoolean("disponible"+i, true)){
                id=i;
                //elementos por defecto
                if(i<8){
                    nombre=sh.getString("nombre"+id,nombsDef[i]);
                    apellidos= sh.getString("apellidos"+id,apesDef[i]);
                    telefono=sh.getString("telefono"+id,"626064578");
                    email=sh.getString("email"+id,emailsDef[i]);
                    direccion=sh.getString("direccion"+id,direccionesDef[i]);
                    apodo=sh.getString("apodo"+id,apodosDef[i]);
                    user=sh.getInt("user"+id,USER[userDef[i]]);
                }else{

                    //USER GENERATED
                    nombre=sh.getString("nombre"+id,"default");
                    apellidos= sh.getString("apellidos"+id,"default");
                    telefono=sh.getString("telefono"+id,"default");
                    email=sh.getString("email"+id,"default");
                    direccion=sh.getString("direccion"+id,"default");
                    apodo=sh.getString("apodo"+id,"default");
                    user=sh.getInt("user"+id,0);
                }
                contactos.add(new Contacts(id,nombre,apellidos,telefono,email,direccion,apodo,user));
            }
        }
        return contactos;
    }

    //DEVUELVE LOS CONTACTOS
    private String[]getNombres(ArrayList<Contacts>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getNombre();
        }
        return toret;
    }

    //DEVUELVE CON IMAGENES
    private int []getUser(ArrayList<Contacts>contactos){
        int toret[]=new int[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getUser();
        }
        return toret;
    }

    //DEVUELVE LOS NICKS
    private String[]getApodos(ArrayList<Contacts>contactos){
        String toret[]=new String[contactos.size()];

        for(int i=0;i<toret.length;i++){
            toret[i]=contactos.get(i).getApodo();
        }
        return toret;
    }

    //RANDOM CONTACTS
    private void randomArray(){
        Collections.shuffle(contactos);
        MyAdapter adapter=new MyAdapter(this, getNombres(contactos), getApodos(contactos), getUser(contactos));
        listView.setAdapter(adapter);
    }
        }

