package com.example.miscontactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Portada extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portada);
    }
        public void CambiarVentana(View view) {

            Intent CambiarVentana = new Intent(this, MainActivity.class);
            startActivity(CambiarVentana);
            finish();
    }
}
